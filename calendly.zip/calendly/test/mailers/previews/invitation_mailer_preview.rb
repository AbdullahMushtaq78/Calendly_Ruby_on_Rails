# Preview all emails at http://localhost:3000/rails/mailers/invitation_mailer
class InvitationMailerPreview < ActionMailer::Preview
    def Invitation_Received
        InvitationMailer.with(event: Event.first, invitation: Invitation.first, user: User.first).Invitation_Received
    end
end

