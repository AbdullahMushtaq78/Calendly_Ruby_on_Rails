require "test_helper"

class PublicEventControllerTest < ActionDispatch::IntegrationTest
  test "should get home" do
    get public_event_home_url
    assert_response :success
  end
end
