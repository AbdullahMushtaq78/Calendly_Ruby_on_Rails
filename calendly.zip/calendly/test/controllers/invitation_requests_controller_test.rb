require "test_helper"

class InvitationRequestsControllerTest < ActionDispatch::IntegrationTest
  test "should get home" do
    get invitation_requests_home_url
    assert_response :success
  end
end
