class AddAcceptedToInvitation < ActiveRecord::Migration[7.0]
  def change
    add_column :invitations, :accepted, :boolean
  end
end
