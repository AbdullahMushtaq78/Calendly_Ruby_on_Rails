class Event < ApplicationRecord
    belongs_to :user
    validates :end_time, comparison: {greater_than_or_equal_to: :start_time}
    has_one_attached :image

    has_many :invitations
end
