class InvitationMailer < ApplicationMailer
    helper :application
    default from: "notifications@calendly.com"

    def Invitation_Received
        @invitation = params[:invitation]
        @event = params[:event]
        @user = params[:user]
        mail(to: @invitation.guest_email, subject: "New Event Invitation.")
    
    end
end
