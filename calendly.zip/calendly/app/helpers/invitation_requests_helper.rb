module InvitationRequestsHelper
    def find_Event(invitation)
        return @inv_event = Event.find(invitation.event_id)
    end
    def find_Sender(sender_id)
        sender = User.find(sender_id)
        return sender
    end

    
end
