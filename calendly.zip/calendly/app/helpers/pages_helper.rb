module PagesHelper
    def CheckFutureEvents(start_time, end_time)
        if start_time.utc > (Time.now + 120.minutes).utc && end_time.utc > (Time.now + 120.minutes).utc
            return true
        else
            return false
        end
    end
    
    def CheckCurrentEvents(start_time, end_time)
        if start_time.utc  <= (Time.now + 120.minutes).utc && (Time.now + 120.minutes).utc  <= end_time.utc
            return true
        else
            return false
        end
    end

end
