class PublicEventController < ApplicationController
  #before_action :authenticate_user!
  def home
    @pub_events = Event.all.where(public:true)
  end
end
