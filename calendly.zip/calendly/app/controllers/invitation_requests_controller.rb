class InvitationRequestsController < ApplicationController
  before_action :authenticate_user!
  def home
    @invitations = Invitation.all.where(guest_email:current_user.email)
    @invitations = @invitations.where(accepted:nil)
  end
end
