class PagesController < ApplicationController
  before_action :authenticate_user!
  def home
    @events = current_user.events.where(
      start_time: Time.now.beginning_of_month.beginning_of_week..Time.now.end_of_month.end_of_week
    )
  end
end
